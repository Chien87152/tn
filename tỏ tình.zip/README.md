### [Hướng dẫn tạo website tán đổ crush đơn giản và hiệu quả || Part 2](https://youtu.be/e2KYBhCx-uU)
> Các bạn download source về và làm theo hướng dẫn trong video nhé.


![cover picture](/img/totinh2021-part2.jpg)

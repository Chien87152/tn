// 1. Chỉnh sửa các dòng chữ theo mục đích của bạn
const CONFIG = {
    introTitle: '🖐🖐🖐 Hee loo ! 🖐🖐🖐',
    introDesc: `Anh có điều này muốn hỏi Em, Em nhớ phải trả lời thật lòng nha`,
    btnIntro: 'OK',
    title: 'Anh biết Em thích Anh phải không phải không ? 😙',
    desc: 'Em không trả lời hoặc thoát ra, tức là Em thích Anh đó nha :> ',
    btnYes: 'Có, em thật sự thích anh 💖💖💖',
    btnNo: '💔 Anh mơ à ! 💔 ',
    question:'Nói cho Anh biết đi vì sao Em thích anh 😊😊',
    reasonPlaceholder: 'Lý do',
    btnReply: 'Gởi ! 💌💌',
    reply: 'Tại vì anh đẹp trai đó Ahiiiii 😊😊',
    mess: 'Anh biết mà, Anh cũng thích em lắm 🥰. Love you 300.000 😘😘',
    messDesc: '💬💬 Nhắn tin cho Anh nha. 💬💬',
    btnAccept: 'Ok lun 💖',
    messLink: 'https://m.me/PhungQuocDinh'
}
